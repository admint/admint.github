# How to build status update reactions using Angular 4 and Firebase
This tutorial covers how to create status update reactions using Angular 4 and Firebase.

[![Get help on Codementor](https://cdn.codementor.io/badges/get_help_github.svg)](https://www.codementor.io/neoighodaro?utm_source=github&utm_medium=button&utm_term=neoighodaro&utm_campaign=github)

![](https://dl.dropbox.com/s/vv8d4z951muu7gj/create-status-update-reactions-angular4-4.gif)

You can follow the [tutorial](tutorial.md)
